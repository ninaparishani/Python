#Basic Module
#A module is simply a file containing functions that we can import into
#other programs.

def formatToDollars(number):
    print("$%4.2f" % (number))
